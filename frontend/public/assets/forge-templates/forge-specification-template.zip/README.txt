FORGE Specification CSV Template
=================================

This package contains the five CSV files used by the FORGE Specification Wizard.

Files
-----
01_entities.csv
02_fields_and_keys.csv
03_foreign_keys.csv
04_relationships.csv
05_constraints.csv

How to use
----------
1. Keep the first header row unchanged.
2. Add one record per row.
3. Use entity and field names consistently across all files.
4. Define entity identities in Fields & Keys.
5. Reference target identity fields when defining foreign keys.
6. Import the completed files into a new or existing Data Model using the
   Specification Wizard.
7. Run Preview and resolve any reported issues before applying the import.

The template is intentionally blank. It does not contain sample data.
